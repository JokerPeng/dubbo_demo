package com.test.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.dubbo.config.annotation.Reference;
import com.test.service.DemoService;

@Controller
@RequestMapping("/demo")
public class DemoController {
	
	@Reference
	DemoService demoService;
	
	@RequestMapping("/index")
	public String hello(){
		System.out.println("消费者");
		demoService.sayHello();
		return "index";
	}
	
	public static void main(String[] args) throws IOException {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext(new String[] {"applicationContext.xml"});
		context.start();
		
		DemoService demoService = (DemoService) context.getBean("demoService");
		demoService.sayHello();
		System.in.read();
	}
}
