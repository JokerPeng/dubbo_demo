package com.test.service.impl;


import com.alibaba.dubbo.config.annotation.Service;
import com.test.service.DemoService;

@Service
public class DemoServiceImpl implements DemoService{

	@Override
	public void sayHello() {
		System.out.println("服务端被调用了.........");
		
	}

}
