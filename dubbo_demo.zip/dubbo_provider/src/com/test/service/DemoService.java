package com.test.service;

public interface DemoService {

	public void sayHello();
}
